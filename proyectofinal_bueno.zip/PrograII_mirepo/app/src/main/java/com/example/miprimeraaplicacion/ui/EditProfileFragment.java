package com.example.miprimeraaplicacion.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.example.miprimeraaplicacion.R;
import com.example.miprimeraaplicacion.db.SQLiteHelper;
import com.example.miprimeraaplicacion.firebase.FirebaseAuthHelper;
import com.example.miprimeraaplicacion.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class EditProfileFragment extends Fragment {

    private ImageButton btnBack;
    private ImageView ivProfilePic;
    private TextInputEditText etUsername;
    private MaterialButton btnSave;

    private ActivityResultLauncher<Intent> camLauncher, galLauncher;
    private String photoBase64 = "";

    private FirebaseAuthHelper authHelper;
    private SQLiteHelper localDb;
    private String uid;

    public EditProfileFragment() {
        super(R.layout.fragment_edit_profile);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        authHelper = new FirebaseAuthHelper();
        localDb = new SQLiteHelper(requireContext());

        FirebaseUser fbUser = FirebaseAuth.getInstance().getCurrentUser();
        if (fbUser == null) {
            Toast.makeText(getContext(), "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            requireActivity().finish();
            return;
        }
        uid = fbUser.getUid();

        btnBack = view.findViewById(R.id.btnBack);
        ivProfilePic = view.findViewById(R.id.ivProfilePic);
        etUsername = view.findViewById(R.id.etUsername);
        btnSave = view.findViewById(R.id.btnSave);
        MaterialButton btnChangePassword = view.findViewById(R.id.btnChangePassword);

        // Cargar datos locales
        User u = localDb.getUser(uid);
        if (u != null) {
            etUsername.setText(u.getName());
            if (u.getPhotoBase64() != null && !u.getPhotoBase64().isEmpty()) {
                byte[] bytes = Base64.decode(u.getPhotoBase64(), Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                ivProfilePic.setImageBitmap(bmp);
                photoBase64 = u.getPhotoBase64();
            }
        }

        setupImagePickers();

        btnBack.setOnClickListener(v -> NavHostFragment.findNavController(this).navigateUp());

        ivProfilePic.setOnClickListener(v -> requestPhotoPermissions());

        btnChangePassword.setOnClickListener(v -> {
            Intent intent = new Intent(requireActivity(), RecoverActivity.class);
            intent.putExtra("source", "profile");
            startActivity(intent);
        });

        btnSave.setOnClickListener(v -> saveProfile());
    }

    private void setupImagePickers() {
        camLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Bitmap bmp = (Bitmap) result.getData().getExtras().get("data");
                        encodeAndShow(bmp);
                    }
                });

        galLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        try {
                            Bitmap bmp = MediaStore.Images.Media.getBitmap(
                                    requireActivity().getContentResolver(), uri);
                            encodeAndShow(bmp);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }

    private void requestPhotoPermissions() {
        String[] perms = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                ? new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES}
                : new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE};

        boolean need = false;
        for (String p : perms) {
            if (ActivityCompat.checkSelfPermission(requireContext(), p)
                    != PackageManager.PERMISSION_GRANTED) {
                need = true;
                break;
            }
        }
        if (need) {
            requestPermissions(perms, 200);
        } else {
            showImagePickerDialog();
        }
    }

    private void showImagePickerDialog() {
        String[] options = {"Tomar foto", "Seleccionar de galería"};
        new AlertDialog.Builder(getContext())
                .setTitle("Seleccionar imagen de perfil")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        camLauncher.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
                    } else {
                        galLauncher.launch(new Intent(Intent.ACTION_PICK,
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI));
                    }
                })
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(req, perms, grantResults);
        boolean granted = true;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }
        if (granted) {
            showImagePickerDialog();
        } else {
            Toast.makeText(getContext(), "Permisos requeridos para cambiar imagen", Toast.LENGTH_SHORT).show();
        }
    }

    private void encodeAndShow(Bitmap bmp) {
        ivProfilePic.setImageBitmap(bmp);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, baos);
        photoBase64 = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
    }

    private void saveProfile() {
        String newName = etUsername.getText().toString().trim();

        if (newName.isEmpty()) {
            Toast.makeText(getContext(), "El nombre no puede quedar vacío", Toast.LENGTH_SHORT).show();
            return;
        }

        btnSave.setEnabled(false);

        // Actualizar Firebase
        authHelper.database.getReference("users").child(uid).child("name").setValue(newName);
        authHelper.database.getReference("users").child(uid).child("photoBase64").setValue(photoBase64);

        // Actualizar base de datos local
        User current = localDb.getUser(uid);
        User updated = new User(
                uid,
                newName,
                current.getEmail(),
                photoBase64,
                current.getFriendCode()
        );
        localDb.saveUser(updated);

        Toast.makeText(getContext(), "Perfil actualizado", Toast.LENGTH_SHORT).show();
        NavHostFragment.findNavController(this).navigateUp();
    }
}



