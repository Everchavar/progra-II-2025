package com.example.miprimeraaplicacion.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.miprimeraaplicacion.R;
import com.example.miprimeraaplicacion.db.SQLiteHelper;
import com.example.miprimeraaplicacion.firebase.FirebaseAuthHelper;
import com.example.miprimeraaplicacion.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private TextView tvGoRegister, tvGoRecover;
    private FirebaseAuthHelper authHelper;
    private SQLiteHelper localDb;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        authHelper = new FirebaseAuthHelper();
        localDb = new SQLiteHelper(this);

        FirebaseUser cur = FirebaseAuth.getInstance().getCurrentUser();
        if (cur != null) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvGoRegister = findViewById(R.id.tvGoRegister);
        tvGoRecover = findViewById(R.id.tvRecover);

        btnLogin.setOnClickListener(v ->
                authHelper.login(
                        etEmail.getText().toString().trim(),
                        etPassword.getText().toString().trim(),
                        new FirebaseAuthHelper.AuthCallback() {
                            @Override
                            public void onSuccess(FirebaseUser user) {
                                authHelper.database.getReference("users")
                                        .child(user.getUid())
                                        .get().addOnSuccessListener(ds -> {
                                            User perfil = ds.getValue(User.class);
                                            if (perfil != null) {
                                                localDb.saveUser(perfil);
                                            }
                                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                            finish();
                                        });
                            }

                            @Override
                            public void onFailure(String error) {
                                Toast.makeText(LoginActivity.this, error, Toast.LENGTH_SHORT).show();
                            }
                        }
                )
        );

        tvGoRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));

        tvGoRecover.setOnClickListener(v -> {
            Intent intent = new Intent(this, RecoverActivity.class);
            intent.putExtra("source", "login");  // 🚨 Añade este extra
            startActivity(intent);
        });
    }
}




