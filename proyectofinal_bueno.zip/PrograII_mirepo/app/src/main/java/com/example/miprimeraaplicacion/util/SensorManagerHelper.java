package com.example.miprimeraaplicacion.util;

import android.content.Context;

public class SensorManagerHelper {
    public SensorManagerHelper(Context context) {
        // init sensores
    }
}

