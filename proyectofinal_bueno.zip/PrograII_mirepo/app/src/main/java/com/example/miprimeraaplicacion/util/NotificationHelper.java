package com.example.miprimeraaplicacion.util;

import android.content.Context;

public class NotificationHelper {
    public static void sendLocalNotification(Context ctx, String title, String msg) {
    }
}
