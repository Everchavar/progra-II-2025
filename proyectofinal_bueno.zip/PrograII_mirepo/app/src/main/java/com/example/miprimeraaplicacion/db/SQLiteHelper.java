package com.example.miprimeraaplicacion.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.miprimeraaplicacion.model.User;

public class SQLiteHelper extends SQLiteOpenHelper {
    private static final String DB_NAME    = "viajes_seguro.db";
    private static final int    DB_VERSION = 1;
    private static final String TABLE_USER = "user";

    public SQLiteHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USER + " (" +
                "id TEXT PRIMARY KEY," +
                "username TEXT," +
                "email TEXT," +
                "photoBase64 TEXT," +
                "friendCode TEXT" +
                ");");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        onCreate(db);
    }

    public void saveUser(User u) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("id", u.getId());
        cv.put("username", u.getName());
        cv.put("email", u.getEmail());
        cv.put("photoBase64", u.getPhotoBase64());
        cv.put("friendCode", u.getFriendCode());
        db.insertWithOnConflict(TABLE_USER, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public User getUser(String id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_USER,
                null,
                "id=?",
                new String[]{ id },
                null, null, null
        );
        User u = null;
        if (c.moveToFirst()) {
            u = new User(
                    c.getString(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("username")),
                    c.getString(c.getColumnIndexOrThrow("email")),
                    c.getString(c.getColumnIndexOrThrow("photoBase64")),
                    c.getString(c.getColumnIndexOrThrow("friendCode"))
            );
        }
        c.close();
        db.close();
        return u;
    }

}


