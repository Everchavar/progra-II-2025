package com.example.miprimeraaplicacion.util;

import com.example.miprimeraaplicacion.api.model.Incident;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.maps.android.heatmaps.HeatmapTileProvider;

import java.util.ArrayList;
import java.util.List;

public class MapUtils {

    /** Configuración inicial del mapa */
    public static void initMap(GoogleMap map) {
        map.getUiSettings().setMyLocationButtonEnabled(false);
        map.getUiSettings().setZoomControlsEnabled(true);
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }

    /** Dibuja un heatmap de incidentes */
    public static void drawHeatmap(GoogleMap map, List<Incident> incidents) {
        // Convertir cada Incident a LatLng
        List<LatLng> points = new ArrayList<>();
        for (Incident inc : incidents) {
            points.add(new LatLng(inc.getLatitude(), inc.getLongitude()));
        }

        // Limpia capas previas (markers, overlays...)
        map.clear();

        // Añade un heatmap si hay datos
        if (!points.isEmpty()) {
            HeatmapTileProvider provider = new HeatmapTileProvider.Builder()
                    .data(points)
                    .build();
            TileOverlayOptions options = new TileOverlayOptions()
                    .tileProvider(provider);
            map.addTileOverlay(options);
        }
    }
}






