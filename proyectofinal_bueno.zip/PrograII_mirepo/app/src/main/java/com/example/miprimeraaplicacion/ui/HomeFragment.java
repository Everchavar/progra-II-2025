package com.example.miprimeraaplicacion.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.example.miprimeraaplicacion.R;
import com.example.miprimeraaplicacion.api.DirectionsApiClient;
import com.example.miprimeraaplicacion.api.DirectionsResponse;
import com.example.miprimeraaplicacion.api.DirectionsService;
import com.example.miprimeraaplicacion.util.PolylineDecoder;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements OnMapReadyCallback {
    private static final int REQ_LOCATION = 100;

    private GoogleMap map;
    private FusedLocationProviderClient locClient;
    private FloatingActionButton fabCenter, fabVerify;

    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onViewCreated(@NonNull android.view.View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 1) Inicializar el AutocompleteSupportFragment directamente
        AutocompleteSupportFragment autocomplete = (AutocompleteSupportFragment)
                getChildFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        autocomplete.setPlaceFields(Arrays.asList(
                Place.Field.LAT_LNG,
                Place.Field.NAME
        ));

        autocomplete.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override public void onPlaceSelected(@NonNull Place place) {
                LatLng dest = place.getLatLng();
                if (dest != null) {
                    map.clear();
                    map.addMarker(new com.google.android.gms.maps.model.MarkerOptions()
                            .position(dest)
                            .title(place.getName()));
                    fetchAndDrawRoute(dest);
                }
            }
            @Override public void onError(@NonNull com.google.android.gms.common.api.Status status) {
                Toast.makeText(getContext(),
                        "Error Autocomplete: " + status.getStatusMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });

        // 2) Inicializar FABs y Mapa
        fabCenter = view.findViewById(R.id.fabCurrentLocation);
        fabVerify = view.findViewById(R.id.fabSendLocation);

        SupportMapFragment mapFrag = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.mapFragment);
        mapFrag.getMapAsync(this);

        locClient = LocationServices
                .getFusedLocationProviderClient(requireActivity());

        fabCenter.setOnClickListener(v -> requestLocationPermissionAndCenter());
        fabVerify.setOnClickListener(v -> {
            // Aquí en el futuro cargarás tus amigos desde la BD local o Firebase.
            // Mientras tanto:
            Toast.makeText(getContext(),
                    "No hay amigos por el momento",
                    Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
        map.getUiSettings().setZoomControlsEnabled(true);
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            map.setMyLocationEnabled(true);
        }
        requestLocationPermissionAndCenter();
    }

    private void requestLocationPermissionAndCenter() {
        if (ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{ Manifest.permission.ACCESS_FINE_LOCATION },
                    REQ_LOCATION);
        } else {
            map.setMyLocationEnabled(true);
            locClient.getLastLocation()
                    .addOnSuccessListener(loc -> {
                        if (loc != null) {
                            LatLng me = new LatLng(loc.getLatitude(), loc.getLongitude());
                            map.animateCamera(CameraUpdateFactory.newLatLngZoom(me, 15));
                        }
                    });
        }
    }

    private void fetchAndDrawRoute(LatLng dest) {
        LatLng origin = map.getCameraPosition().target;
        DirectionsService svc = DirectionsApiClient.getClient()
                .create(DirectionsService.class);
        svc.getRoute(
                origin.latitude + "," + origin.longitude,
                dest.latitude   + "," + dest.longitude,
                getString(R.string.google_maps_key)
        ).enqueue(new Callback<DirectionsResponse>() {
            @Override public void onResponse(Call<DirectionsResponse> call,
                                             Response<DirectionsResponse> res) {
                if (res.isSuccessful()
                        && res.body() != null
                        && !res.body().routes.isEmpty()) {

                    String pts = res.body()
                            .routes
                            .get(0)
                            .overview_polyline
                            .points;

                    map.addPolyline(new PolylineOptions()
                            .addAll(PolylineDecoder.decode(pts))
                            .width(8)
                    );
                    map.animateCamera(CameraUpdateFactory.newLatLngZoom(dest, 14));
                }
            }
            @Override public void onFailure(Call<DirectionsResponse> c, Throwable t) {
                Toast.makeText(getContext(),
                        "Error al trazar ruta: " + t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int code,
                                           @NonNull String[] perms, @NonNull int[] grants) {
        super.onRequestPermissionsResult(code, perms, grants);
        if (code == REQ_LOCATION
                && grants.length > 0
                && grants[0] == PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {

                map.setMyLocationEnabled(true);
                requestLocationPermissionAndCenter();
            }
        } else {
            Toast.makeText(getContext(),
                    "Permiso de ubicación denegado",
                    Toast.LENGTH_SHORT).show();
        }
    }
}







