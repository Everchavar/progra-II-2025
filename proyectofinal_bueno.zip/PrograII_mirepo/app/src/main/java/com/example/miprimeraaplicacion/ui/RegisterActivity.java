package com.example.miprimeraaplicacion.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.miprimeraaplicacion.R;
import com.example.miprimeraaplicacion.db.SQLiteHelper;
import com.example.miprimeraaplicacion.firebase.FirebaseAuthHelper;
import com.example.miprimeraaplicacion.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etUsername, etEmail, etPass, etPassConf;
    private MaterialButton   btnRegister;
    private ImageView        ivProfilePic;
    private String           photo64 = ""; // puede quedar vacío
    private FirebaseAuthHelper authHelper;
    private SQLiteHelper       localDb;

    private ActivityResultLauncher<Intent> camL;
    private ActivityResultLauncher<Intent> galL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Flecha Up
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Registro");
        }

        authHelper = new FirebaseAuthHelper();
        localDb    = new SQLiteHelper(this);

        etUsername   = findViewById(R.id.etUsername);
        etEmail      = findViewById(R.id.etEmailReg);
        etPass       = findViewById(R.id.etPasswordReg);
        etPassConf   = findViewById(R.id.etPasswordConfirm);
        btnRegister  = findViewById(R.id.btnRegister);
        ivProfilePic = findViewById(R.id.ivProfilePic);

        setupImagePickers();

        ivProfilePic.setOnClickListener(v -> showImageSourceDialog());
        btnRegister .setOnClickListener(v -> performRegister());
    }

    // Volver a LoginActivity
    @Override
    public boolean onSupportNavigateUp() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
        return true;
    }

    private void setupImagePickers() {
        camL = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData()!=null) {
                        Bitmap bmp = (Bitmap) result.getData().getExtras().get("data");
                        encodeAndShow(bmp);
                    }
                });
        galL = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData()!=null) {
                        Uri uri = result.getData().getData();
                        try {
                            Bitmap bmp = MediaStore.Images.Media.getBitmap(
                                    getContentResolver(), uri);
                            encodeAndShow(bmp);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }

    // Diálogo para elegir cámara o galería
    private void showImageSourceDialog() {
        String[] options = { "Tomar foto", "Elegir de galería" };
        new AlertDialog.Builder(this)
                .setTitle("Selecciona una opción")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        requestPermissionsAndOpenCamera();
                    } else {
                        requestPermissionsAndOpenGallery();
                    }
                })
                .show();
    }

    private void requestPermissionsAndOpenCamera() {
        // Solo pedir CAMERA; para galería otro permiso
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{ Manifest.permission.CAMERA }, 200);
        } else {
            camL.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
        }
    }

    private void requestPermissionsAndOpenGallery() {
        String perm = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;

        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{ perm }, 300);
        } else {
            galL.launch(new Intent(Intent.ACTION_PICK,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 200) {
            if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) {
                camL.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
            } else {
                Toast.makeText(this,
                        "Permiso cámara denegado",
                        Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == 300) {
            if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) {
                galL.launch(new Intent(Intent.ACTION_PICK,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI));
            } else {
                Toast.makeText(this,
                        "Permiso galería denegado",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void encodeAndShow(Bitmap bmp) {
        ivProfilePic.setImageBitmap(bmp);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, baos);
        photo64 = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
    }

    private void performRegister() {
        String u = etUsername.getText().toString().trim();
        String e = etEmail   .getText().toString().trim();
        String p = etPass    .getText().toString().trim();
        String c = etPassConf.getText().toString().trim();

        // Sólo validamos nombre, email y contraseñas
        if (u.isEmpty() || e.isEmpty() || p.isEmpty() || c.isEmpty()) {
            Toast.makeText(this,
                    "Rellena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!p.equals(c)) {
            Toast.makeText(this,
                    "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
            return;
        }
        // photo64 puede estar vacío sin problema

        btnRegister.setEnabled(false);
        authHelper.register(u, e, p, photo64, new FirebaseAuthHelper.AuthCallback() {
            @Override
            public void onSuccess(FirebaseUser user) {
                // Resto sin cambios...
                FirebaseDatabase.getInstance()
                        .getReference("users")
                        .child(user.getUid())
                        .get()
                        .addOnSuccessListener(ds -> {
                            User perfil = ds.getValue(User.class);
                            if (perfil != null) localDb.saveUser(perfil);
                            Toast.makeText(RegisterActivity.this,
                                    "Registro exitoso", Toast.LENGTH_SHORT).show();
                            finish();
                        })
                        .addOnFailureListener(ex -> {
                            Toast.makeText(RegisterActivity.this,
                                    "Error al cargar perfil: " + ex.getMessage(),
                                    Toast.LENGTH_LONG).show();
                            btnRegister.setEnabled(true);
                        });
            }
            @Override
            public void onFailure(String error) {
                btnRegister.setEnabled(true);
                Toast.makeText(RegisterActivity.this,
                        error, Toast.LENGTH_SHORT).show();
            }
        });
    }
}


