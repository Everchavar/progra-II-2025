package com.example.miprimeraaplicacion.firebase;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.example.miprimeraaplicacion.model.User;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.*;
import com.google.firebase.database.FirebaseDatabase;

import java.security.SecureRandom;
import java.util.Locale;

public class FirebaseAuthHelper {

    private final FirebaseAuth auth = FirebaseAuth.getInstance();
    public final FirebaseDatabase database = FirebaseDatabase.getInstance();

    public interface AuthCallback {
        void onSuccess(FirebaseUser user);
        void onFailure(String error);
    }

    public interface VoidCallback {
        void onSuccess();
        void onFailure(String error);
    }

    /** LOGIN */
    public void login(String email, String password, AuthCallback cb) {
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            cb.onFailure("Email y contraseña requeridos");
            return;
        }
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = auth.getCurrentUser();
                        if (user != null) cb.onSuccess(user);
                        else cb.onFailure("Usuario nulo");
                    } else {
                        cb.onFailure(task.getException().getMessage());
                    }
                });
    }

    /** REGISTER */
    public void register(String username, String email, String password,
                         String photoBase64, AuthCallback cb) {
        // Sólo validamos nombre, email y password:
        if (TextUtils.isEmpty(username)
                || TextUtils.isEmpty(email)
                || TextUtils.isEmpty(password)) {
            cb.onFailure("Nombre, email y contraseña son obligatorios");
            return;
        }
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        cb.onFailure(task.getException().getMessage());
                        return;
                    }
                    FirebaseUser user = auth.getCurrentUser();
                    if (user == null) {
                        cb.onFailure("Error interno: usuario nulo");
                        return;
                    }
                    // Generar friendCode
                    String friendCode = generateFriendCode();
                    // Creamos el objeto User incluyendo photoBase64, aunque esté vacío:
                    User perfil = new User(
                            user.getUid(),
                            username,
                            email,
                            photoBase64,   // si está vacío, OK
                            friendCode
                    );
                    // Guardar en Realtime DB
                    database.getReference("users")
                            .child(user.getUid())
                            .setValue(perfil)
                            .addOnCompleteListener(dbTask -> {
                                if (!dbTask.isSuccessful()) {
                                    cb.onFailure(dbTask.getException().getMessage());
                                } else {
                                    cb.onSuccess(user);
                                }
                            });
                });
    }


    /** RECOVER PASSWORD */
    public void recoverPassword(String email, VoidCallback cb) {
        if (TextUtils.isEmpty(email)) {
            cb.onFailure("Email requerido");
            return;
        }
        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) cb.onSuccess();
                    else cb.onFailure(task.getException().getMessage());
                });
    }

    /** SIGN OUT */
    public void signOut() {
        auth.signOut();
    }

    /** Genera un código hexadecimal de 8 dígitos */
    private String generateFriendCode() {
        // Genera un entero aleatorio de 32 bits
        int randInt = new SecureRandom().nextInt();
        // Convierte a un valor sin signo de 32 bits
        long unsigned = randInt & 0xFFFFFFFFL;
        // Formatea a 8 dígitos hex (mayúsculas)
        return String.format(Locale.US, "%08X", unsigned);
    }
}






