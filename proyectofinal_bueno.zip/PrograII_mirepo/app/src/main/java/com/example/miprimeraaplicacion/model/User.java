package com.example.miprimeraaplicacion.model;

public class User {
    private String id;
    private String name;
    private String email;
    private String photoBase64;
    private String friendCode;

    public User() {}

    public User(String id, String name, String email,
                String photoBase64, String friendCode) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.photoBase64 = photoBase64;
        this.friendCode = friendCode;
    }

    // Getters y setters
    public String getId()            { return id; }
    public String getName()          { return name; }
    public String getEmail()         { return email; }
    public String getPhotoBase64()   { return photoBase64; }
    public String getFriendCode()    { return friendCode; }
    public void setPhotoBase64(String s){ this.photoBase64 = s; }
}


