package com.example.miprimeraaplicacion.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.example.miprimeraaplicacion.R;
import com.example.miprimeraaplicacion.db.SQLiteHelper;
import com.example.miprimeraaplicacion.firebase.FirebaseAuthHelper;
import com.example.miprimeraaplicacion.model.User;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ProfileFragment extends Fragment {

    private MaterialCardView cardEdit, cardLogout;
    private ImageView ivProfilePic;
    private TextView tvUsername, tvEmail, tvFriendCode;
    private ImageButton btnCopyCode;

    public ProfileFragment() {
        super(R.layout.fragment_profile);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ivProfilePic  = view.findViewById(R.id.ivProfilePic);
        tvUsername    = view.findViewById(R.id.tvUsername);
        tvEmail       = view.findViewById(R.id.tvEmail);
        tvFriendCode  = view.findViewById(R.id.tvFriendCode);
        btnCopyCode   = view.findViewById(R.id.btnCopyCode);
        cardEdit      = view.findViewById(R.id.card_edit);
        cardLogout    = view.findViewById(R.id.card_logout);

        FirebaseUser fbUser = FirebaseAuth.getInstance().getCurrentUser();
        if (fbUser != null) {
            // 1) Carga desde SQLite
            SQLiteHelper db = new SQLiteHelper(requireContext());
            User u = db.getUser(fbUser.getUid());
            if (u != null) bindUser(u);

            // 2) Refresca desde Firebase y actualiza local
            new FirebaseAuthHelper().database
                    .getReference("users")
                    .child(fbUser.getUid())
                    .get()
                    .addOnSuccessListener(ds -> {
                        User remote = ds.getValue(User.class);
                        if (remote != null) {
                            db.saveUser(remote);
                            bindUser(remote);
                        }
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(getContext(),
                                    "Error cargar perfil: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show()
                    );
        }

        NavController nav = NavHostFragment.findNavController(this);
        cardEdit.setOnClickListener(v ->
                nav.navigate(R.id.action_profileFragment_to_editProfileFragment)
        );
        cardLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(getContext(),
                    "Sesión cerrada con éxito",
                    Toast.LENGTH_SHORT).show();
            startActivity(new Intent(requireActivity(), LoginActivity.class));
            requireActivity().finish();
        });

        btnCopyCode.setOnClickListener(v -> {
            String code = tvFriendCode.getText().toString().replace("Código: ", "");
            ClipboardManager cm = (ClipboardManager)
                    requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("friendCode", code));
            Toast.makeText(getContext(),
                    "Código copiado al portapapeles",
                    Toast.LENGTH_SHORT).show();
        });
    }

    private void bindUser(User u) {
        tvUsername   .setText(u.getName());
        tvEmail      .setText(u.getEmail());
        tvFriendCode .setText("Código: " + u.getFriendCode());

        String b64 = u.getPhotoBase64();
        if (b64 != null && !b64.isEmpty()) {
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            Bitmap bmp   = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            ivProfilePic.setImageBitmap(bmp);
        }
    }
}






