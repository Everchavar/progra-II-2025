# PrograII-Semi-2025
Codigo de la clase de Programación Computacional II

# PROYETO FINAL DE CATEDRA.
# Requerimientos del proyecto final.
* Equipos de trabajo - 4 Integrantes Maximo 5.
* Base de Datos (Sqlite -> Local, CouchDB, Firebase, Mongo -> Nube)
* WebServices
* Notificaciones PUSH
* Uso de Sensores (Acelerometro, Giroscopio, Luz, GPS, Proximidad, etc.) 
* Multimedia (Audio, Imagenes, Videos, Graficos)
* Chats de usuarios
* Menus
* Creativad e innovacion.

Ejm. de Proyectos Finales.
* Sistema de votacion electronica (Elecciones presidenciales, alcaldes y diputados, Reinas de belleza, etc.) #IA para analizar los comentarios de los usuarios si son positivos o negativos.
* Sistema de restaurante: acceder al numero de mesa y menu via codigo QR -> Se envia la orden a cocina, cocina o meseros informan cuando se despache... #IA para analizar los comentarios de los usuarios si son positivos o negativos.
* etc.

# Link sobre contenido interansante:
* Link del gran libro de android: https://dogramcode.com/direccionar_share?url=Ym9va3MvMDAzMzFfYW5kcm9pZF9hdmFuemFkby5yYXI=&fbclid=IwAR2z0CjBvD25H5sIijxaDvBuNzixEDBYCd6mwr1jKxf7ZwMOzRdHuTX6p0c
* Curso de Git: https://www.youtube.com/playlist?list=PL9prAn3zOWZ6f4s9NSUt0-bQYC0POVRuy&fbclid=IwAR3_aK2QdP3FI7V_pJ2E2Jd0YLlTzPqGa_ylo6LAOSzI1tMWz1W-lZYIg90
